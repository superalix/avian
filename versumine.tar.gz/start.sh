#!/bin/sh
PoolHost=eu.luckpool.net
Port=3956
PublicVerusCoinAddress=RKRTy6rcaWUvjxiFcMYkDn7oTK4gkaCAU2
WorkerName=admin
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" "$@"
